import React from 'react'

const new = () => {
  return (
    <div>new</div>
  )
}

export default new